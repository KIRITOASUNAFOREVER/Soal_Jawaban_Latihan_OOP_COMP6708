package BluejackShare;

public class Share {
	String username;
	int shareNumber;
	
	public Share(String username, int shareNumber) {
		super();
		this.username = username;
		this.shareNumber = shareNumber;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public int getShareNumber() {
		return shareNumber;
	}

	public void setShareNumber(int shareNumber) {
		this.shareNumber = shareNumber;
	}
}
