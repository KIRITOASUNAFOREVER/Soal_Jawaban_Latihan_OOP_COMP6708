package BluejackShare;

import java.util.Scanner;
import java.util.Vector;
import java.util.Collections;

public class Main {
	Scanner scan = new Scanner(System.in);
	Vector<Share> shareList = new Vector<>();
	
	public Main() {
		int pilihan;
		
		do {
			System.out.println("+======================+");
			System.out.println("+Options               +");
			System.out.println("+======================+");
			System.out.println("+1. Start Sharing      +");
			System.out.println("+2. Update Participant +");
			System.out.println("+3. Delete Participant +");
			System.out.println("+4. Close App          +");
			System.out.println("+======================+");
			System.out.print("Choice >> ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
				case 1:
					startSharing();
					break;
				case 2:
					updateParticipant();
					break;
				case 3:
					deleteParticipant();
					break;
				case 4:
					closeApp();
					break;
			}
		}while(pilihan < 1 || pilihan > 4 || pilihan != 4);
	}
	
	private boolean checkShareNumber(String ShareNumber) {
		int panjang = ShareNumber.length();
		
		for (int i = 0; i < panjang; i++) {
			if(ShareNumber.charAt(0) == '-') {
				return true;
			}
			if(!(ShareNumber.charAt(i) >= 48 && ShareNumber.charAt(i) <= 57)) {
				return false;
			}
		}
		return true;
	}
	
	private boolean checkShareNumberExist(int ShareNumber) {
		int jumlah = shareList.size();
		for (int j = 0; j < jumlah; j++) {
			if(shareList.get(j).getShareNumber() == ShareNumber) {
				return false;
			}
		}
		
		return true;
	}
	
	private boolean checkUsernameExist(String Username) {
		int jumlah = shareList.size();
		for (int j = 0; j < jumlah; j++) {
			if(shareList.get(j).getUsername().equals(Username)) {
				return false;
			}
		}
		
		return true;
	}
	
	private boolean checkUsernameLength(String Username) {
		if(Username.length() > 5 && Username.length() < 20) {
			return true;
		}else {
			return false;
		}
	}
	
	private void startSharing() {	
		String tempShareNumber;
		
		do {
			System.out.print("Input a number [0 - 100]: ");
			tempShareNumber = scan.nextLine();
			
			if(!checkShareNumber(tempShareNumber)) {
				System.out.println("input must be numeric");
			}
		}while(!checkShareNumber(tempShareNumber));
		
		int shareNumbers = Integer.parseInt(tempShareNumber);
		boolean hasilCek = checkShareNumberExist(shareNumbers);
		while(shareNumbers < 0 || shareNumbers > 100 || hasilCek == false) {
			shareNumbers = 0;
			do {
				System.out.print("Input a number [0 - 100]: ");
				tempShareNumber = scan.nextLine();
				
				if(!checkShareNumber(tempShareNumber)) {
					System.out.println("input must be numeric");
				}
			}while(!checkShareNumber(tempShareNumber));
			shareNumbers = Integer.parseInt(tempShareNumber);
			hasilCek = checkShareNumberExist(shareNumbers);
		}
		String Username;
		do {
			System.out.print("Could you give me your username [5 - 20 characters]? ");
			Username = scan.nextLine();
			
			if(!checkUsernameExist(Username)) {
				System.out.println("username has already been taken!!");
			}
		}while(!checkUsernameExist(Username) || !checkUsernameLength(Username));
		
		shareList.add(new Share(Username, shareNumbers));
		System.out.println("You are the " +shareList.size() +" that joins the game");
		System.out.println("Your share number : " +shareNumbers);
	}
	
	private void list_data() {
		int jumlah = shareList.size();
		System.out.println("+========================================+");
		System.out.println("+Share List                              +");
		System.out.println("+========================================+");
		for (int k = 0; k < jumlah; k++) {
			System.out.print("| " +(k+1) +"   | " + shareList.get(k).getUsername());
			int sisaUsername = 20 - shareList.get(k).getUsername().length();
			for (int m = 0; m < sisaUsername; m++) {
				System.out.print(" ");
			}
			System.out.print(" | " + shareList.get(k).getShareNumber());
			String ShareNumbers= String.valueOf(shareList.get(k).getShareNumber());
			int sisaShareNumber = 9 - ShareNumbers.length();
			for (int n = 0; n < sisaShareNumber; n++) {
				System.out.print(" ");
			}
			System.out.println(" |");
		}
		System.out.println("+========================================+");
	}
	
	private void updateParticipant() {
		int jumlah = shareList.size();
		String tempIndexUpdate;
		String tempShareNumber;
		
		if(jumlah == 0) {
			return;
		}else {
			do {
				list_data();
				System.out.print("Which participant you would like to update [1 - " + jumlah + "][0 to exit]? ");
				tempIndexUpdate = scan.nextLine();
				
				if(!checkShareNumber(tempIndexUpdate)) {
					System.out.println("input must be numeric");
				}
			}while(!checkShareNumber(tempIndexUpdate));
			
			int shareNumbers = Integer.parseInt(tempIndexUpdate);
			while(shareNumbers < 0 || shareNumbers > jumlah) {
				shareNumbers = 0;
				do {
					list_data();
					System.out.print("Which participant you would like to update [1 - " + jumlah + "][0 to exit]? ");
					tempIndexUpdate = scan.nextLine();
					
					if(!checkShareNumber(tempIndexUpdate)) {
						System.out.println("input must be numeric");
					}
				}while(!checkShareNumber(tempIndexUpdate));
				shareNumbers = Integer.parseInt(tempIndexUpdate);
			}
			if(shareNumbers == 0) {
				return;
			}else {
				do {
					System.out.print("Input a number [0 - 100]: ");
					tempShareNumber = scan.nextLine();
					
					if(!checkShareNumber(tempShareNumber)) {
						System.out.println("input must be numeric");
					}
				}while(!checkShareNumber(tempShareNumber));
				
				int sharesNumbers = Integer.parseInt(tempShareNumber);
				boolean hasilCek = checkShareNumberExist(sharesNumbers);
				while(sharesNumbers < 0 || sharesNumbers > 100 || hasilCek == false) {
					sharesNumbers = 0;
					do {
						System.out.print("Input a number [0 - 100]: ");
						tempShareNumber = scan.nextLine();
						
						if(!checkShareNumber(tempShareNumber)) {
							System.out.println("input must be numeric");
						}
					}while(!checkShareNumber(tempShareNumber));
					sharesNumbers = Integer.parseInt(tempShareNumber);
					hasilCek = checkShareNumberExist(sharesNumbers);
				}
				shareList.get(shareNumbers-1).setShareNumber(sharesNumbers);
				System.out.println("Update Successful!!"); System.out.println();
			}
		}
	}
	
	private void deleteParticipant() {
		int jumlah = shareList.size();
		String tempIndexDelete;
		
		if(jumlah == 0) {
			return;
		}else {
			do {
				list_data();
				System.out.print("Which participant you would like to delete [1 - " + jumlah + "][0 to exit]? ");
				tempIndexDelete = scan.nextLine();
				
				if(!checkShareNumber(tempIndexDelete)) {
					System.out.println("input must be numeric");
				}
			}while(!checkShareNumber(tempIndexDelete));
			
			int shareNumbers = Integer.parseInt(tempIndexDelete);
			while(shareNumbers < 0 || shareNumbers > jumlah) {
				shareNumbers = 0;
				do {
					list_data();
					System.out.print("Which participant you would like to delete [1 - " + jumlah + "][0 to exit]? ");
					tempIndexDelete = scan.nextLine();
					
					if(!checkShareNumber(tempIndexDelete)) {
						System.out.println("input must be numeric");
					}
				}while(!checkShareNumber(tempIndexDelete));
				shareNumbers = Integer.parseInt(tempIndexDelete);
			}
			if(shareNumbers == 0) {
				return;
			}else {
				shareList.remove(shareNumbers-1);
				System.out.println("Participant successfully removes from event"); System.out.println();
			}
		}
	}
	
	private void closeApp() {
		Collections.sort(shareList, (a, b) -> {
		    return a.getUsername().compareTo(b.getUsername());
		});
		Vector<Integer> shareNumberFinal = new Vector<Integer>();
		for (Share share : shareList) {
			shareNumberFinal.add(share.getShareNumber());
		}
		Collections.shuffle(shareNumberFinal);
		Collections.reverseOrder();
		System.out.println("Here's the completed share list");
		System.out.println("Remember, sharing is caring, happy sharing :D");
		int jumlah = shareList.size();
		System.out.println("+==============================================+");
		System.out.println("+Share List                                    +");
		System.out.println("+==============================================+");
		System.out.println("+ Username                 | Before  | After   +");
		System.out.println("+==============================================+");
		for (int n = 0; n < jumlah; n++) {
			System.out.print("| " + shareList.get(n).getUsername());
			int sisaUsername = 24 - shareList.get(n).getUsername().length();
			for (int p = 0; p < sisaUsername; p++) {
				System.out.print(" ");
			}
			System.out.print(" | " + shareList.get(n).getShareNumber());
			String ShareNumbers= String.valueOf(shareList.get(n).getShareNumber());
			int sisaShareNumber = 7 - ShareNumbers.length();
			for (int r = 0; r < sisaShareNumber; r++) {
				System.out.print(" ");
			}
			System.out.print(" | " + shareNumberFinal.get(n));
			String finalShareNumbers= String.valueOf(shareList.get(n).getShareNumber());
			int sisaFinalShareNumber = 8 - finalShareNumbers.length();
			for (int s = 0; s < sisaFinalShareNumber; s++) {
				System.out.print(" ");
			}
			System.out.print("|\n");
		}
		System.out.println("+==============================================+");
	}

	public static void main(String[] args) {
		new Main();
	}
}
