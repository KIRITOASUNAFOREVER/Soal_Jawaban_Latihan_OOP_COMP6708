package RistoranteGustoso;

public class Customer {
	String customerName;
	String customerGender;
	
	public Customer(String customerName, String customerGender) {
		super();
		this.customerName = customerName;
		this.customerGender = customerGender;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	public String getCustomerGender() {
		return customerGender;
	}

	public void setCustomerGender(String customerGender) {
		this.customerGender = customerGender;
	}
}
