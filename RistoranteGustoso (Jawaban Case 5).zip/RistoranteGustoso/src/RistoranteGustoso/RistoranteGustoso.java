package RistoranteGustoso;

import java.util.Scanner;
import java.util.Vector;

public class RistoranteGustoso {
	Scanner scan = new Scanner(System.in);
	Vector<Menu> menuList = new Vector<>();
	Vector<Customer> customerList = new Vector<>();
	Vector<Comment> commentList = new Vector<>();
	
	public RistoranteGustoso() {
		int pilihan;
		int counter = 0;
		
		if(counter == 0) {
			menuList.add(new Menu("Gelato (ice cream)", 85000));
			menuList.add(new Menu("Agliata", 65000));
			menuList.add(new Menu("Bagna cauda", 55000));
			menuList.add(new Menu("Cioppino", 100000));
			menuList.add(new Menu("Minestrone", 95000));
			menuList.add(new Menu("Risi e bisi", 45000));
			menuList.add(new Menu("Pesto", 35000));
			menuList.add(new Menu("Neccio", 25000));
			menuList.add(new Menu("Testarolo", 40000));
			menuList.add(new Menu("Calzone", 45000));
			
			counter++;
		}
		
		do {
			System.out.println("Ristorante Gustoso");
			System.out.println("1. View all restaurant data");
			System.out.println("2. Input new customer");
			System.out.println("3. Input rates");
			System.out.println("4. Exit");
			System.out.print(">> ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
				case 1:
					viewAllRestaurantData();
					break;
				case 2:
					inputNewCustomer();
					break;
				case 3:
					inputRates();
					break;
			}
		}while(pilihan < 1 || pilihan > 4 || pilihan != 4);
	}
	
	private void viewAllRestaurantData() {
		int choice;
		
		do {
			System.out.println();
			System.out.println("Ristorante Gustoso");
			System.out.println("1. View menus");
			System.out.println("2. View customers");
			System.out.println("3. View ratings");
			System.out.println("4. Back");
			System.out.print(">> ");
			choice = scan.nextInt(); scan.nextLine();
			
			switch(choice) {
				case 1:
					viewMenus();
					break;
				case 2:
					viewCustomers();
					break;
				case 3:
					viewRatings();
					break;
				case 4:
					BacktoMenu();
					break;
			}
		}while(choice < 1 || choice > 4 || choice != 4);
	}
	
	private void viewMenus() {
		System.out.println();
		System.out.println("Ristorante Gustoso");
		int jumlah = menuList.size();
		
		for (int i = 0; i < jumlah; i++) {
			System.out.println((i+1) + ". " + menuList.get(i).getMenuName() + " - " + menuList.get(i).getMenuPrice());
		}
		System.out.println();
		System.out.print("Press Enter to go back...");
		scan.nextLine(); System.out.println(); System.out.println();
	}
	
	private void viewCustomers() {
		int jumlahCustomer = customerList.size();
		
		if(jumlahCustomer == 0) {
			System.out.println();
			System.out.println("Ristorante Gustoso");
			System.out.println("No data");
			System.out.println();
			System.out.print("Press Enter to go back...");
			scan.nextLine(); System.out.println(); System.out.println();
			return;
		}
		
		System.out.println();
		System.out.println("Ristorante Gustoso");
		for (int m = 0; m < jumlahCustomer; m++) {
			System.out.println((m+1) + ". " + customerList.get(m).getCustomerName() + " - " + customerList.get(m).getCustomerGender());
		}
		System.out.println();
		System.out.print("Press Enter to go back...");
		scan.nextLine(); System.out.println(); System.out.println();
	}
	
	private void viewRatings() {
		int jumlahComment = commentList.size();
		
		if(jumlahComment == 0) {
			System.out.println();
			System.out.println("Ristorante Gustoso");
			System.out.println("No data");
			System.out.println();
			System.out.print("Press Enter to go back...");
			scan.nextLine(); System.out.println(); System.out.println();
			return;
		}
		
		System.out.println();
		System.out.println("Ristorante Gustoso");
		for (int n = 0; n < jumlahComment; n++) {
			System.out.println((n+1) + ". " + commentList.get(n).getRestaurantRating() + " - " + commentList.get(n).getRestaurantComment());
		}
		System.out.println();
		System.out.print("Press Enter to go back...");
		scan.nextLine(); System.out.println(); System.out.println();
	}
	
	private void BacktoMenu() {
		return;
	}
	
	private boolean checkCustomerNameLength(String arr[]) {
		if(arr.length >= 1) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkCustomerGender(String CustomerGender) {
		if(CustomerGender.equalsIgnoreCase("male") || CustomerGender.equalsIgnoreCase("female")) {
			return true;
		}else {
			return false;
		}
	}
	
	private void inputNewCustomer() {
		String CustomerName;
		String arr[];
		boolean hasilCekNama = false;
		do {
			System.out.println("Input the name of the customer");
			System.out.print(">> ");
			CustomerName = scan.nextLine();
			arr = CustomerName.split(" ");
			hasilCekNama = CustomerName.isEmpty();
		}while(!checkCustomerNameLength(arr) || hasilCekNama);
		
		String CustomerGender;
		do {
			System.out.println("Input the gender of the customer");
			System.out.print(">> ");
			CustomerGender = scan.nextLine();
		}while(!checkCustomerGender(CustomerGender));
		CustomerGender = CustomerGender.toLowerCase();
		
		customerList.add(new Customer(CustomerName, CustomerGender));
		System.out.print("Success input user's data, press enter  to back...");
		scan.nextLine(); System.out.println(); System.out.println();
	}
	
	private boolean checkRestaurantRating(String RestaurantRatings) {
		int panjang = RestaurantRatings.length();
		int tanda   = 0; 
		
		for (int i = 0; i < panjang; i++) {
			if(RestaurantRatings.charAt(i) >= 48 && RestaurantRatings.charAt(i) <= 57) {
				tanda = 1;
			}
		}
		
		int RestaurantsRatings;
		if(tanda==1) {
			RestaurantsRatings = Integer.parseInt(RestaurantRatings);
			if(RestaurantsRatings > 1 && RestaurantsRatings < 10) {
				return true;
			}else {
				return false;
			}
		}else {
			return false;
		}
	}
	
	private boolean checkRestaurantComment(String RestaurantComments) {
		if(RestaurantComments.length() > 30) {
			return false;
		}
		
		return true;
	}
	
	private void inputRates() {
		String RestaurantRating;
		do {
			System.out.println("Input the rating of the restaurant");
			System.out.print(">> ");
			RestaurantRating = scan.nextLine();
		}while(!checkRestaurantRating(RestaurantRating));
		int restaurantRatings;
		restaurantRatings = Integer.parseInt(RestaurantRating);
		
		String RestaurantComment;
		do {
			System.out.println("Input the comment of the restaurant");
			System.out.print(">> ");
			RestaurantComment = scan.nextLine();
		}while(!checkRestaurantComment(RestaurantComment));
		
		commentList.add(new Comment(restaurantRatings, RestaurantComment));
	}

	public static void main(String[] args) {
		new RistoranteGustoso();
	}
}
