package RistoranteGustoso;

public class Comment {
	int restaurantRating;
	String restaurantComment;
	
	public Comment(int restaurantRating, String restaurantComment) {
		super();
		this.restaurantRating = restaurantRating;
		this.restaurantComment = restaurantComment;
	}

	public int getRestaurantRating() {
		return restaurantRating;
	}

	public void setRestaurantRating(int restaurantRating) {
		this.restaurantRating = restaurantRating;
	}

	public String getRestaurantComment() {
		return restaurantComment;
	}

	public void setRestaurantComment(String restaurantComment) {
		this.restaurantComment = restaurantComment;
	}
}
