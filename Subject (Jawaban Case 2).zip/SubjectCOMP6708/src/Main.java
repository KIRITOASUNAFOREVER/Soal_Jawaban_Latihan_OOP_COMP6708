import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner(System.in);
	
	public Main() {
		int pilihan;
		
		do {
			System.out.println("SUBJECT");
			System.out.println("=======");
			System.out.println("1. Mathematics");
			System.out.println("2. English");
			System.out.println("3. Exit");
			System.out.print("Choice: ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
				case 1:
					mathematicsMenu();
					break;
				case 2:
					englishMenu();
					break;
			}
		}while(pilihan < 1 || pilihan > 3 || pilihan != 3);
	}
	
	private void mathematicsMenu() {
		int choice;
		
		do {
			System.out.println("MATH MENU");
			System.out.println("=========");
			System.out.println("1. Calculate circle area");
			System.out.println("2. Calculate rectangle area");
			System.out.print("Choice: ");
			choice = scan.nextInt(); scan.nextLine();
			
			switch(choice) {
				case 1:
					calculateCircleArea();
					break;
				case 2:
					calculateRectangleArea();
					break;
			}
		}while(choice < 1 || choice > 2);
	}
	
	private void calculateCircleArea() {
		Circle circle = new Circle();
		circle.inputCircleType(scan);
		circle.displayCircleAreaResult();
	}
	
	private void calculateRectangleArea() {
		Rectangle rectangle = new Rectangle();
		rectangle.inputRectangleDetails(scan);
		rectangle.displayRectangleAreaResult();
	}
	
	private void englishMenu() {
		String word;
		String arr[];
		do {
			System.out.print("Input word[only 1 word | muat only be alphabet]: ");
			word = scan.nextLine();
			arr = word.split(" ");
		}while(!checkWordLength(arr));
		
		String tensesType;
		do {
			System.out.print("Input tenses type[Present | Past](Case Sensitive): ");
			tensesType = scan.nextLine();
		}while(!checkTensesType(tensesType));
		
		if(tensesType.equals("Present")) {
			printPresentResult(word);
		}else if(tensesType.equals("Past")) {
			printPastResult(word);
		}
	}
	
	private boolean checkWordLength(String arr[]) {
		if(arr.length == 1) {
			return true;
		}else {
			return false;
		}
	}
	
	private boolean checkTensesType(String TensesType) {
		if(TensesType.equals("Present") || TensesType.equals("Past")) {
			return true;
		}else {
			return false;
		}
	}
	
	private void printPresentResult(String Word) {
		int panjangKata = Word.length();
		System.out.println("==============================");
		if(Word.charAt(panjangKata-1) == 's' || (Word.charAt(panjangKata-2) == 'e' && Word.charAt(panjangKata-1) == 's')) {
			System.out.println(Word + " is a plural word");
		}else {
			System.out.println(Word + " is a singular word");
		}
		System.out.println("It contains of " + panjangKata + " character(s)");
		System.out.println();
		System.out.println("Press any key to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
	
	private void printPastResult(String Word) {
		int panjangKata = Word.length();
		System.out.println("==============================");
		if(Word.charAt(panjangKata-1) == 'd' || (Word.charAt(panjangKata-2) == 'e' && Word.charAt(panjangKata-1) == 'd')) {
			System.out.println(Word + " is a regular verb");
		}else {
			System.out.println(Word + " is a irregular verb");
		}
		System.out.println("It contains of " + panjangKata + " character(s)");
		System.out.println();
		System.out.println("Press any key to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}

	public static void main(String[] args) {
		new Main();
	}
}