import java.util.Scanner;

public class Circle extends CalculateArea{
	
	String CircleType;
	
	public String getCircleType() {
		return CircleType;
	}

	public void setCircleType(String circleType) {
		CircleType = circleType;
	}

	public Circle() {
		super();
	}
	
	double radius, diameter;
	
	String[] areaOption = {"Radius", "Diameter"};
	private boolean validateOption(String Option){
        if (Option.equals("radius") || Option.equals("diameter")){
            return true;
        }
        return false;
    } 
	
	void inputCircleType(Scanner scanner){
        do{
            System.out.print("Choose input type[");
            for (int i = 0; i < areaOption.length; i++) {
                System.out.print(areaOption[i]);
                if(i == areaOption.length-1){
                    System.out.print("] ");
                }else{
                    System.out.print(" | ");
                }
            }
            System.out.print("(Case Insensitive): ");
            CircleType = scanner.nextLine();
            CircleType = CircleType.toLowerCase();
        }while (!validateOption(CircleType));
        
        if(CircleType.equals("radius")) {
        	int min = 1;
        	int max = 100;
        	radius = Math.random()*(max-min+1)+min;    
        }else if(CircleType.equals("diameter")) {
        	int min = 1;
        	int max = 100;
        	diameter = Math.random()*(max-min+1)+min;
        }
    }

	@Override
	double calculateArea() {
		double circleArea = 0;
		
		if(radius == 0) {
			circleArea = (double)(Math.PI * ((diameter * 2) * (diameter * 2)));
		}else if(diameter == 0) {
			circleArea = (double)(Math.PI * radius * radius);
		}
		
		return circleArea;
	}
	
	void displayCircleAreaResult() {
		double circleAreaResult = calculateArea();
		Scanner scan = new Scanner(System.in);
		
		if(radius == 0) {
			System.out.println();
			System.out.println("===============================");
			System.out.println("The generated diameter value is " + (int)diameter);
			System.out.println("The area of the circle is " +circleAreaResult);
			System.out.println("press any key to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
		}else if(diameter == 0) {
			System.out.println();
			System.out.println("===============================");
			System.out.println("The generated radius value is " + (int)radius);
			System.out.println("The area of the circle is " +circleAreaResult);
			System.out.println("press any key to continue...");
			scan.nextLine();
			System.out.println(); System.out.println();
		}
	}
}
