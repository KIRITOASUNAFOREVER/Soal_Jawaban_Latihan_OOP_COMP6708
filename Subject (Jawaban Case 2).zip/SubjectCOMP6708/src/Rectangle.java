import java.util.Scanner;

public class Rectangle extends CalculateArea {
	
	String rectangleInput;
	
	public String getRectangleInput() {
		return rectangleInput;
	}

	public void setRectangleInput(String rectangleInput) {
		this.rectangleInput = rectangleInput;
	}

	public Rectangle() {
		super();
	}
	
	private boolean checkRectangleDetails(String arr[]) {
		int tanda = -1;
		if(arr.length == 2) {
			for (int i = 0; i < arr[0].length(); i++) {
				if(arr[0].charAt(i) >= 48 && arr[0].charAt(i) <= 57) {
					tanda = 1;
				}else {
					tanda = 0;
					break;
				}
			}
			
			for (int j = 0; j < arr[1].length(); j++) {
				if(arr[1].charAt(j) >= 48 && arr[1].charAt(j) <= 57) {
					tanda = 1;
				}else {
					tanda = 0;
					break;
				}
			}
			
			if(tanda==1) {
				return true;
			}else {
				return false;
			}
			
		}else {
			return false;
		}
	}
	
	int panjang = 0, lebar = 0;
	
	void inputRectangleDetails(Scanner scanner){
		String arr[];
        do{
            System.out.print("Input width and length[format: WidthxLength]: ");
            rectangleInput = scanner.nextLine();
            arr = rectangleInput.split("x");
        }while (!checkRectangleDetails(arr));
        
        panjang = Integer.parseInt(arr[0]);
        lebar = Integer.parseInt(arr[1]);
    }

	@Override
	double calculateArea() {
		double rectangleArea = 0;
		rectangleArea = panjang * lebar;
		
		return rectangleArea;
	}
	
	void displayRectangleAreaResult() {
		int rectangleAreaResult = (int)calculateArea();
		
		Scanner scan = new Scanner(System.in);
		
		System.out.println();
		System.out.println("===============================");
		System.out.println("The area of rectangle is " + (int)rectangleAreaResult);
		System.out.println();
		System.out.println("press any key to continue...");
		scan.nextLine();
		System.out.println(); System.out.println();
	}
}
