
public abstract class CalculateArea {
	abstract double calculateArea();
}
