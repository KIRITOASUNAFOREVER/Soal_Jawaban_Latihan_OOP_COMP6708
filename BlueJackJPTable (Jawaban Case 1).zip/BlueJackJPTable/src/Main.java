import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner(System.in);
	boolean p1, p2;
	
	public Main() {
		int pilihan;
		
		do {
			System.out.println("1. Start The Simulation!!");
			System.out.println("2. Close App");
			System.out.print("Choice >> ");
			pilihan = scan.nextInt(); scan.nextLine();
			
			switch(pilihan) {
				case 1:
					startSimulation();
					break;
				case 2:
					closeApp();
					break;
			}
		}while(pilihan < 1 || pilihan > 2 || pilihan != 2);	
	}
	
	private boolean checkNumber(int FirstNumber) {
		if(FirstNumber > 1 && FirstNumber < 100) {
			return true;
		}else {
			return false;
		}
	}
	
	private void printBasicJavaDataTypes(int FirstNumber, int SecondNumber) {
		String pertama = Integer.toString(FirstNumber);
		String kedua = Integer.toString(SecondNumber);
		String penjumlahan = pertama + " + " + kedua;
		
		char first =(char)FirstNumber;
		char second =(char)SecondNumber;
		
		int hasilKali = FirstNumber * SecondNumber;
		
		double hasilBagi = (double)FirstNumber/(double)SecondNumber;
		
		String hasilSama;
		boolean angkaSama = (FirstNumber == SecondNumber);
		if(angkaSama == false) {
			hasilSama = "False";
		}else {
			hasilSama = "True";
		}
		
		System.out.println("+=========================================================================================================================+");
		System.out.println("+  + (String type)  |  (Character Type)  |  * (Integer type)  |  / (Floating Type)  |  input 1 == input 2 (Boolean Type)  +");
		System.out.println("+=========================================================================================================================+");
		System.out.printf("+     %-12s  |       %c   %c        |        %-10d  |         %.3f       |                %-20s +\n",penjumlahan,first,second,hasilKali,hasilBagi,hasilSama);
		System.out.println("+=========================================================================================================================+");
		System.out.println("Press enter to proceed..");
		scan.nextLine(); System.out.println(); System.out.println();
	}
	
	private void printBasicArithmeticOperation(int FirstNumber, int SecondNumber) {
		int hasilJumlah = FirstNumber + SecondNumber;
		int hasilKurang = FirstNumber - SecondNumber;
		int hasilPerkalian = FirstNumber * SecondNumber;
		int hasilPembagian = FirstNumber / SecondNumber;
		int hasilModulo = FirstNumber % SecondNumber;
		
		System.out.println("+============================================================+");
		System.out.printf("+%-20s","Data Type : Integer" +"                                         +\n");
		System.out.println("+============================================================+");
		System.out.println("+     +     |     -     |     *      |     /     |     %     +");
		System.out.println("+============================================================+");
		System.out.printf("+    %-6d |    %-6d |    %-7d |    %-6d |    %-6d +\n",hasilJumlah,hasilKurang,hasilPerkalian,hasilPembagian,hasilModulo);
		System.out.println("+============================================================+");
		System.out.println("Press enter to proceed..");
		scan.nextLine(); System.out.println(); System.out.println();
	}
	
	private boolean inputBooleanValue1() {
		String MyString = "";
		
		System.out.print("Give me value for p1 [true | false]: ");
		MyString = scan.nextLine();
		MyString.toLowerCase();
		Scanner MyScan = new Scanner(MyString);
		if(!MyScan.hasNext()) {
			inputBooleanValue1();
		}
		while(MyScan.hasNext()) {
		      if(MyScan.hasNextBoolean()) {
		    	  p1 = MyScan.nextBoolean();
		      }
		      else {
		    	  inputBooleanValue1();
		    	  break;
		      }  
		}
		return p1;
	}
	
	private boolean inputBooleanValue2() {
		String MyString = "";
		
		System.out.print("Give me value for p2 [true | false]: ");
		MyString = scan.nextLine();
		MyString.toLowerCase();
		Scanner MyScan = new Scanner(MyString);
		if(!MyScan.hasNext()) {
			inputBooleanValue2();
		}
		while(MyScan.hasNext()) {
		      if(MyScan.hasNextBoolean()) {
		    	  p2 = MyScan.nextBoolean();
		      }
		      else {
		    	  inputBooleanValue2();
		    	  break;
		      }  
		}
		return p2;
	}
	
	private void printLogicalTable(boolean p1, boolean p2) {
		String tanda1, tanda2;
		if(p1==true) {
			tanda1 = "T";
		}else {
			tanda1 = "F";
		}
		
		if(p2==true) {
			tanda2 = "T";
		}else {
			tanda2 = "F";
		}
		
		String negasi1,negasi2,ampersand, doublepipe;
		if((!p1) == true) {
			negasi1 = "true";
		}else {
			negasi1 = "false";
		}
		
		if((!p2) == true) {
			negasi2 = "true";
		}else {
			negasi2 = "false";
		}
		
		if((p1&&p2) == true) {
			ampersand = "true";
		}else {
			ampersand = "false";
		}
		
		if((p1||p2) == true) {
			doublepipe = "true";
		}else {
			doublepipe = "false";
		}
		System.out.println("+====================================================================+");
		System.out.println("+Logical Table                                                       +");
		System.out.println("+====================================================================+");
		System.out.println("+ P1 = " +tanda1 + " , P2 = " +tanda2 +"                                                    +");
		System.out.println("+====================================================================+");
		System.out.println("+      !P1       |       !P2       |       &&       |       ||       +");
		System.out.println("+====================================================================+");
		System.out.printf("+     %-10s |      %-9s |      %-9s |      %-9s  +\n",negasi1,negasi2,ampersand,doublepipe);
		System.out.println("+====================================================================+");
		System.out.println(); System.out.println();
	}
	
	private void startSimulation() {
		int firstNumber, secondNumber;
		
		do {
			System.out.print("Input the first number [1 - 100](inclusive): ");
			firstNumber = scan.nextInt(); scan.nextLine();
		}while(!checkNumber(firstNumber));
		
		do {
			System.out.print("Input the second number [1 - 100](inclusive): ");
			secondNumber = scan.nextInt(); scan.nextLine();
		}while(!checkNumber(secondNumber));
		
		printBasicJavaDataTypes(firstNumber,secondNumber);
		printBasicArithmeticOperation(firstNumber,secondNumber);
		
		p1 = inputBooleanValue1();
		p2 = inputBooleanValue2();
		
		printLogicalTable(p1,p2);
	}
	
	private void closeApp() {
		System.out.println("thank you for using the apps!!");
	}

	public static void main(String[] args) {
		new Main();
	}
}