import java.util.Scanner;
import java.util.Vector;

public class Utama {
	Scanner scan = new Scanner(System.in);
	Vector<Pet>PetList = new Vector<>();
	
	void addPetData()
	{
		int tempPetHealth;
		String tempPetName;
		String tempPetType;
		String tempPetSound;
		
		do {
		    System.out.print("Input pet health [1 - 90]: ");
		    while (!scan.hasNextInt()) {
		    	System.out.print("Input pet health [1 - 90]: ");
		        scan.next(); scan.nextLine();
		    }
		    tempPetHealth = scan.nextInt();scan.nextLine();
		} while (tempPetHealth < 1 || tempPetHealth > 90 );
		
		do{
			System.out.print("Input pet name [5 - 15 characters]: ");
			tempPetName = scan.nextLine();
		}while(tempPetName.length() < 5 || tempPetName.length() > 15);
		
		do{
			System.out.print("Input pet type [kit | puppy | kitten]: ");
			tempPetType = scan.nextLine();
		}while(!(tempPetType.equals("kit") || tempPetType.equals("puppy") || tempPetType.equals("kitten")));
		
		tempPetSound = "unknown";
		
		PetList.add(new Pet(tempPetHealth, tempPetName, tempPetType, tempPetSound));
		
		System.out.println("Pet successfully added to the list...");
		scan.nextLine();
	}
	
	void viewPetData()
	{
		int jumlah = PetList.size();
		
		if(jumlah==0)
		{
			System.out.println("+==========================================================+");
			System.out.println("+ No |        Name         |   Type   |   Sound   | Health +");
			System.out.println("+==========================================================+");
			System.out.println("+ Empty -                                                  +");
			System.out.println("+==========================================================+");
			
			System.out.println();
		}
		else
		{
			for (int i = 0; i < PetList.size(); i++) {
				if(PetList.get(i).getPetType().equals("kit") && !(PetList.get(i).getPetName().contains("Rabbit")))
				{
					PetList.get(i).setPetSound("clucking");
					String tambahan =  "Rabbit ";
					String baru = tambahan.concat(PetList.get(i).getPetName());
					PetList.get(i).setPetName(baru);
				}
				else if(PetList.get(i).getPetType().equals("puppy") && !(PetList.get(i).getPetName().contains("Dog")))
				{
					PetList.get(i).setPetSound("bark bark");
					String tambahan =  "Dog ";
					String baru = tambahan.concat(PetList.get(i).getPetName());
					PetList.get(i).setPetName(baru);
				}
				else if(PetList.get(i).getPetType().equals("kitten") && !(PetList.get(i).getPetName().contains("Cat")))
				{
					PetList.get(i).setPetSound("meow meow");
					String tambahan =  "Cat ";
					String baru = tambahan.concat(PetList.get(i).getPetName());
					PetList.get(i).setPetName(baru);
				}
			}
			
			System.out.println("+==========================================================+");
			System.out.println("+ No |        Name         |   Type   |   Sound   | Health +");
			System.out.println("+==========================================================+");
			for (int i = 0; i < PetList.size(); i++) {
				System.out.printf("+ %d  | %-19s | %-8s | %-9s | %-2d     +\n",  i+1,PetList.get(i).getPetName(),
						PetList.get(i).getPetType(),PetList.get(i).getPetSound(),PetList.get(i).getPetHealth());
			}
			System.out.println("+==========================================================+");		
		}
		System.out.println();
	}
	
	void updatePetData()
	{
		int jumlah = PetList.size();
		int update;
		int tempPetHealth;
		int tempPetHealth1 = 0;
		int finalPetHealth;
		
		if(jumlah==0)
		{
			return;
		}
		else
		{
			viewPetData();
			
			
			do {
			    System.out.print("Choose pet number to update [1 - "+PetList.size()+"]: ");
			    while (!scan.hasNextInt()) {
			    	System.out.print("Choose pet number to update [1 - "+PetList.size()+"]: ");
			        scan.next(); scan.nextLine();
			    }
			    update = scan.nextInt();scan.nextLine();
			} while (update < 1 || update > PetList.size());
			
			do {
			    System.out.print("Input pet health [1 - 90]: ");
			    while (!scan.hasNextInt()) {
			    	System.out.print("Input pet health [1 - 90]: ");
			        scan.next(); scan.nextLine();
			    }
			    tempPetHealth = scan.nextInt();scan.nextLine();
			} while (tempPetHealth < 1 || tempPetHealth > 90 );
			tempPetHealth1 = PetList.get(update-1).getPetHealth();
			System.out.println(tempPetHealth1);
			if(tempPetHealth < 20)
			{
				tempPetHealth1 = 25;
				PetList.get(update-1).setPetHealth(tempPetHealth1);
				
				if(tempPetHealth1 < tempPetHealth)
				{
					finalPetHealth = (tempPetHealth + tempPetHealth1)/2;
					PetList.get(update-1).setPetHealth(finalPetHealth);
				}
			}
			else
			{
				if(tempPetHealth < tempPetHealth1)
				{
					finalPetHealth = (tempPetHealth + tempPetHealth1)/2;
					PetList.get(update-1).setPetHealth(finalPetHealth);
				}
				else
				{
					PetList.get(update-1).setPetHealth(tempPetHealth);
				}
			}
			
			System.out.println("Pet health updated..");
		}
	}
	
	void treatPetData()
	{
		int jumlah = PetList.size();
		int treat;
		
		if(jumlah==0)
		{
			System.out.println();
			return;
		}
		else
		{
			viewPetData();
			
			do {
			    System.out.print("Choose pet number to be treated [1 - "+PetList.size()+"]: ");
			    while (!scan.hasNextInt()) {
			    	System.out.print("Choose pet number to be treated [1 - "+PetList.size()+"]: ");
			        scan.next(); scan.nextLine();
			    }
			    treat = scan.nextInt();scan.nextLine();
			} while (treat < 1 || treat > PetList.size());
			
			PetList.remove(treat-1);
			System.out.println("Pets Treated!!");
		}
	}
	
	public Utama() {
		int choose;
		
		do{
			System.out.println("BJ-Vet");
			System.out.println("+=====================+");
			System.out.println("+Menu                 +");
			System.out.println("+=====================+");
			System.out.println("+1. Add Sick Pet      +");
			System.out.println("+2. View Sick List    +");
			System.out.println("+3. Update Pet Health +");
			System.out.println("+4. Treat Pet         +");
			System.out.println("+5. Exit Program      +");
			System.out.println("+=====================+");
			System.out.print("Choice >> ");
			choose = scan.nextInt();scan.nextLine();
			
			switch(choose)
			{
			case 1:
				addPetData();
				break;
			case 2:
				viewPetData();
				break;
			case 3:
				updatePetData();
				break;
			case 4:
				treatPetData();
				break;
			case 5:
				System.out.println("Thanks for using BJ-Vet Program");
				break;
			}
		}while(choose > 5 || choose < 1 || choose!=5);
		
	}

	public static void main(String[] args) {
		new Utama();
	}
}
